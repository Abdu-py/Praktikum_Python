import turtle

t = turtle.Turtle()
s = turtle.Screen()
s.bgcolor('black')
t.speed(0)

for i in range(17):
    t.color('purple')
    t.begin_fill()
    t.circle(190-i, 90)
    t.left(98)
    t.end_fill()
    t.color('pink')
    t.begin_fill()
    t.circle(190-i, 90)
    t.left(18)
    t.end_fill()
s.exitonclick()